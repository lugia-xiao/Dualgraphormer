import torch

## This function is used to ensure that each feature is non-overlapping.
def convert_to_single_emb(x, offset=512):
    feature_num = x.size(1) if len(x.size()) > 1 else 1
    feature_offset = 1 + torch.arange(0, feature_num * offset, offset, dtype=torch.long,device=x.device)
    x = x + feature_offset
    return x

def random_walk(matrix,num_hops):
    M=torch.diag_embed(torch.nan_to_num(1/torch.sum(matrix,dim=-1), nan=0))@matrix.float()
    results=[torch.eye(matrix.shape[0]).to(matrix.device)]
    for i in range(num_hops):
        results.append(results[-1]@M)
    return torch.stack(results,dim=-1)

def process_item(item,num_hops):
    edge_attr, edge_index, x = item.edge_attr, item.edge_index, item.x
    N = x.size(0)

    node_x = convert_to_single_emb(x)
    node_adj = torch.sparse_coo_tensor(indices=edge_index, values=torch.ones((edge_index.shape[-1]),device=x.device),
                                  size=(N, N)).to_dense().bool().to(x.device)
    if len(edge_attr.size()) == 1:
        edge_attr = edge_attr[:, None]
    node_edges = torch.zeros([N, N, edge_attr.size(-1)], dtype=torch.long,device=x.device)
    node_edges[edge_index[0, :], edge_index[1, :]] = convert_to_single_emb(edge_attr) + 1

    return [node_x,node_edges,torch.sum(node_adj,dim=-1),random_walk(node_adj,num_hops)]