import os
import torch
import pandas as pd
import numpy as np
import random
from ogb.lsc import PCQM4Mv2Evaluator
from ogb.utils import smiles2graph
from ogb.lsc import PygPCQM4Mv2Dataset
from torch_geometric.data import DataLoader

from model import GRIT_plus
from lr import PolynomialDecayLR


def squeeze(y_preds, y):
    if len(y_preds.shape) == 2:
        y_preds = y_preds.squeeze(dim=-1)
    if len(y.shape) == 2:
        y = y.squeeze(dim=-1)
    return y_preds, y


def get_result_dict(y_preds, y):
    y_true = torch.concat(y, dim=0)
    y = torch.concat(y_preds, dim=0)
    if len(y_true.shape) == 2:
        y_true = y_true.squeeze(dim=-1)
    if len(y.shape) == 2:
        y = y.squeeze(dim=-1)
    return {"y_true": y_true,
            "y_pred": y}


def set_all_seeds(seed: int):
    """
    Set seed for reproducibility in PyTorch, NumPy, and Python's random.

    Parameters:
    - seed (int): The seed value to be set.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


if __name__ == "__main__":
    current_epoch = 0
    current_step = 0
    epochs = 150
    batch_size = 256
    peak_lr = 2e-4
    end_lr = 1e-9
    total_updates = 1e6

    seed = 114514
    set_all_seeds(seed)

    dataset = PygPCQM4Mv2Dataset(root='../../dataset/', smiles2graph=smiles2graph)

    split_dict = dataset.get_idx_split()
    train_loader = DataLoader(dataset[split_dict['train']], batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(dataset[split_dict["valid"]], batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(dataset[split_dict['test-dev']], batch_size=batch_size, shuffle=False)
    challenge_loader = DataLoader(dataset[split_dict['test-challenge']], batch_size=batch_size, shuffle=False)

    warmup_updates = len(train_loader)*10/batch_size

    print("train loader length:", len(train_loader))
    print("val loader length:", len(val_loader))
    print("test loader length:", len(test_loader))
    print("challenge loader length", len(challenge_loader))

    my_model = GRIT_plus(node_dim=128,edge_dim=64,num_heads=4,n_layers=8,num_hops=16).cuda()

    optimizer = torch.optim.AdamW(my_model.parameters(), betas=(0.9, 0.999), eps=1e-8,
                                  lr=peak_lr)  # torch.optim.AdamW(my_model.parameters(), lr=peak_lr, betas=(0.99, 0.999))
                                  
    loss_func = torch.nn.L1Loss().cuda()  # Unbalanced_BCE_logits_loss().cuda()
    evaluator = PCQM4Mv2Evaluator()
    records = []
    best_val = 1e10

    if sum([filei.find("PCQ_current_hyper_reasonable.pth") >= 0 for filei in os.listdir(".")]) > 0:
        checkpoint = torch.load("PCQ_current_hyper_reasonable.pth")
        my_model.load_state_dict(checkpoint['model'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        current_epoch = checkpoint['epoch']
        current_step = checkpoint['step']
        records = checkpoint['records']
        seed = checkpoint['seed']
        set_all_seeds(seed)
        if 'best_val' in checkpoint:
            best_val = checkpoint['best_val']

    print("start from:")
    print("current_epoch", current_epoch, "current_step", current_step, "seed", seed)

    for epochi in range(current_epoch, epochs):
        best_save_flag = False

        my_model.train()
        loss_train = 0
        y_preds_train = []
        y_train = []
        train_roc = 0
        for (stepi, x) in enumerate(train_loader, start=1):
            if epochi == current_epoch and stepi <= current_step - 1:
                continue
            y_pred = my_model(x.cuda())
            y = x.y.to(torch.float32).cuda()
            y_pred, y = squeeze(y_pred, y)
            lossi = loss_func(y_pred, y)
            lossi.backward()
            optimizer.step()
            optimizer.zero_grad()

            loss_train = loss_train + lossi.cpu().item()
            y_train.append(y.cpu().detach())
            y_preds_train.append(y_pred.cpu().detach())
            torch.cuda.empty_cache()
            if stepi % 20 == 0:
                print("Training-> epoch:", epochi, "step:", stepi, "loss:", loss_train / stepi,
                      evaluator.eval(get_result_dict(y_preds_train, y_train)))
            if stepi % 1000 == 0:
                checkpoints = {
                    'model': my_model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'epoch': epochi,
                    'step': stepi,
                    'records': records,
                    'seed': seed,
                    'best_val': best_val
                }
                torch.save(checkpoints, "PCQ_current_hyper_reasonable.pth")
        # get_acc(y_preds_train, y_train)
        result_dict = evaluator.eval(get_result_dict(y_preds_train, y_train))
        print("Finish training, epoch:", epochi, result_dict)
        train_roc = evaluator.eval(get_result_dict(y_preds_train, y_train))['mae']
        print("rocauc:", train_roc)

        seed = seed + epochi + 1
        set_all_seeds(seed)

        my_model.eval()
        loss_val = 0
        y_preds_val = []
        y_val = []
        val_roc = 0
        with torch.no_grad():
            for (stepi, x) in enumerate(val_loader, start=1):
                y_pred = my_model(x.cuda())
                y = x.y.to(torch.float32).cuda()
                lossi = loss_func(y_pred, y)
                loss_val = loss_val + lossi.cpu().item()

                y_val.append(y.cpu().detach())
                y_preds_val.append(y_pred.cpu().detach())
                torch.cuda.empty_cache()
                if stepi % 20 == 0:
                    print("Validating-> epoch:", epochi, "step:", stepi, "loss:", loss_val / stepi
                          , evaluator.eval(get_result_dict(y_preds_val, y_val)))

        result_dict = evaluator.eval(get_result_dict(y_preds_val, y_val))
        print("Finish validating, epoch:", epochi, result_dict)
        val_roc = evaluator.eval(get_result_dict(y_preds_val, y_val))['mae']
        print("rocauc:", val_roc)

        if val_roc < best_val:
            best_save_flag = True
            best_val = val_roc
            torch.save(my_model.state_dict(), "dualgraphormer_hyper_reasonable.pth")
            checkpoints = {
                'model': my_model.state_dict(),
                'optimizer': optimizer.state_dict(),
                'epoch': epochi + 1,
                'step': 0,
                'records': records,
                'seed': seed,
                'best_val': best_val
            }
            torch.save(checkpoints, "PCQ_current_hyper_reasonable.pth")

        y_preds_test = []
        y_test = []
        with torch.no_grad():
            for (stepi, x) in enumerate(test_loader, start=1):
                y_pred = my_model(x.cuda())
                y = x.y.to(torch.float32).cuda()

                y_test.append(y.cpu().detach())
                y_preds_test.append(y_pred.cpu().detach())
                torch.cuda.empty_cache()
                if stepi % 20 == 0:
                    print("Testing-> epoch:", epochi, "step:", stepi)

        print("Finish testing, epoch:", epochi)
        if best_save_flag:
            evaluator.save_test_submission(input_dict=get_result_dict(y_preds_test, y_test),
                                           dir_path="submit_dev_hyper_reasonable.npz",
                                           mode='test-dev')
        test_roc = evaluator.eval(get_result_dict(y_preds_test, y_test))

        y_preds_challenge = []
        y_challenge = []
        with torch.no_grad():
            for (stepi, x) in enumerate(challenge_loader, start=1):
                y_pred = my_model(x.cuda())
                y = x.y.to(torch.float32).cuda()

                y_challenge.append(y.cpu().detach())
                y_preds_challenge.append(y_pred.cpu().detach())
                torch.cuda.empty_cache()
                if stepi % 20 == 0:
                    print("challenging-> epoch:", epochi, "step:", stepi)
        print("Finish challenging, epoch:", epochi)
        challenge_roc = evaluator.eval(get_result_dict(y_preds_challenge, y_challenge))
        if best_save_flag:
            evaluator.save_test_submission(input_dict=get_result_dict(y_preds_challenge, y_challenge),
                                           dir_path="submit_challenge_hyper_reasonable.npz",
                                           mode='test-challenge')

        if len(records) != 0 and len(records[0]) != 5:
            records = []
        records.append([epochi, loss_train, loss_val, train_roc, val_roc])
        df = pd.DataFrame(columns=["epoch", "loss_train", "loss_val", "train_roc", "val_roc"], data=records)
        df.to_csv("./records_PCQ_hyper_reasonable.csv")