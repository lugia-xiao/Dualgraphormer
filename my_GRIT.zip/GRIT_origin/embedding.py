import torch
import torch.nn as nn

class Embedding(nn.Module):
    def __init__(
        self,node_dim,edge_dim,num_hops,input_dropout_rate=0.1,dataset_name="ogbg-molhiv"
    ):
        super().__init__()
        if dataset_name == 'ZINC':
            self.atom_encoder = nn.Embedding(64, node_dim, padding_idx=0)
            self.edge_encoder = nn.Embedding(64, edge_dim, padding_idx=0)
        else:
            self.atom_encoder = nn.Embedding(512*9 + 1, node_dim, padding_idx=0)
            self.edge_encoder = nn.Embedding(512*3 + 1, edge_dim, padding_idx=0)

        self.input_dropout=nn.Dropout(input_dropout_rate)

    def forward(self,x):
        node_data = x[0]
        edge_data = x[1]

        node_features = self.atom_encoder(node_data).sum(dim=-2)
        #node_features=torch.concat([node_features,torch.diagonal(x[3],dim1=0,dim2=1).permute(1,0)],dim=-1)

        edge_features = self.edge_encoder(edge_data).sum(dim=-2)
        #edge_features=torch.concat([edge_features,x[3]],dim=-1)

        node_features=self.input_dropout(node_features)
        edge_features=self.input_dropout(edge_features)

        return [node_features,edge_features,x[2],x[3]]