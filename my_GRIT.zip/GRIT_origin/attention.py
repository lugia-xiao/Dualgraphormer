import torch
import torch.nn as nn
import torch.nn.functional as F

class FFN(nn.Module):
    def __init__(self,dim,in_dim=None,out_dim=None):
        super().__init__()
        if in_dim is None:
            in_dim=dim
        if out_dim is None:
            out_dim=dim

        self.linear1=nn.Linear(in_dim,dim*4)
        self.linear2=nn.Linear(dim*4,out_dim)
        self.act=nn.GELU()

    def forward(self,x):
        return self.linear2(self.act(self.linear1(x)))

'''class Random_Walk_advanced(nn.Module):
    def __init__(self,node_dim,edge_dim,rw_dim,num_hops):
        super().__init__()
        self.num_hops=num_hops

        self.edge_transform=nn.Linear(edge_dim,edge_dim,bias=False)

        self.W_K1=nn.Linear(edge_dim,edge_dim,bias=False)
        self.W_Q1=nn.Linear(edge_dim,edge_dim,bias=False)
        self.W_K2=nn.Linear(edge_dim, edge_dim, bias=False)
        self.W_Q2=nn.Linear(edge_dim, edge_dim, bias=False)
        self.W_Nw=nn.Linear(node_dim,edge_dim,bias=False)
        self.W=nn.Linear(edge_dim,rw_dim,bias=False)

    def forward(self,nodes,edges,adj):
        N=nodes.shape[0]
        M=torch.diag_embed(torch.nan_to_num(1/torch.sum(adj,dim=-1), nan=0))@adj.float()
        node=self.W_Nw(nodes).unsqueeze(dim=1).repeat(1,N,1)

        tmp_edge=self.edge_transform(edges).permute(2,0,1)
        tmp_topology=M
        result=[]
        for i in range(self.num_hops):
            K=(tmp_edge@M).permute(1,2,0)
            Q=(tmp_topology@edges.permute(2,0,1)@M).permute(1,2,0)
            tmp_values=F.relu(rho(node*(self.W_K1(K)+self.W_Q1(Q)))+self.W_K2(K)+self.W_Q2(Q))
            tmp_topology=tmp_topology@M
            tmp_edge=tmp_values.permute(2,0,1)
            result.append(self.W(tmp_values))
        return torch.concat(result,dim=-1)'''

def rho(x):
    return torch.sqrt(F.relu(x))-torch.sqrt(F.relu(-x))

class GRIT_attention(nn.Module):
    def __init__(self,node_dim,edge_dim,num_hops,rw_dim=4):
        super().__init__()

        self.W_Q=nn.Linear(node_dim+rw_dim*num_hops,edge_dim+rw_dim*num_hops, bias=False)
        self.W_K = nn.Linear(node_dim+rw_dim*num_hops, edge_dim+rw_dim*num_hops, bias=False)
        self.W_V = nn.Linear(node_dim+rw_dim*num_hops, node_dim+rw_dim*num_hops, bias=False)
        self.W_Ew = nn.Linear(edge_dim+rw_dim*num_hops, edge_dim+rw_dim*num_hops, bias=False)
        self.W_Eb = nn.Linear(edge_dim+rw_dim*num_hops, edge_dim+rw_dim*num_hops, bias=False)
        self.W_Ev=nn.Linear(edge_dim+rw_dim*num_hops,node_dim+rw_dim*num_hops,bias=False)
        self.W_A = nn.Linear(edge_dim+rw_dim*num_hops, 1, bias=False)

        #self.rw=Random_Walk_advanced(node_dim,edge_dim,rw_dim,num_hops)

        self.linear_node=nn.Linear(rw_dim*num_hops+node_dim,node_dim,bias=False)
        self.linear_edge=nn.Linear(rw_dim*num_hops+edge_dim,edge_dim,bias=False)

    def forward(self,x):
        node, edge, adj, rw=x
        N,C=node.shape
        edge = torch.concat([edge, rw], dim=-1)

        diag = torch.diagonal(rw, dim1=0, dim2=1)
        node = torch.concat([node, diag.permute(1, 0)], dim=-1)

        Q=self.W_Q(node).unsqueeze(dim=1).repeat(1,N,1)
        K=self.W_K(node).unsqueeze(dim=0).repeat(N,1,1)#n,n,c_e
        edge=F.relu(rho((Q+K)*self.W_Ew(edge))+self.W_Eb(edge))#n,n,c_e

        alpha=F.softmax(self.W_A(edge).squeeze(dim=-1),dim=-1)#n,n

        node=alpha@(self.W_V(node)+self.W_Ev(torch.sum(edge,dim=-2)))

        node=self.linear_node(node)
        edge=self.linear_edge(edge)
        return [node, edge]

class Multi_Head_Attention(nn.Module):
    def __init__(self,node_dim,edge_dim,num_heads,num_hops,rw_dim=4):
        super().__init__()
        self.attentions=nn.ModuleList(
            [GRIT_attention(node_dim,edge_dim,num_hops,rw_dim) for i in range(num_heads)]
        )
        #self.W_h = nn.Linear(num_heads,1,bias=False)
        #self.W_he = nn.Linear(num_heads,1,bias=False)


    def forward(self,x):
        result=[]
        for attentioni in self.attentions:
            result.append(attentioni([x[0],x[1],x[2],x[3]]))

        nodes=[tmp[0] for tmp in result]
        nodes=torch.stack(nodes,dim=-1)
        nodes=torch.sum(nodes,dim=-1)#self.W_h(nodes).squeeze(dim=-1)

        edge=[tmp[1] for tmp in result]
        edge=torch.stack(edge,dim=-1)
        edge=torch.sum(edge,dim=-1)#self.W_he(edge).squeeze(dim=-1)

        return [nodes,edge,x[2],x[3]]

class DegScaler(nn.Module):
    def __init__(self,node_dim):
        super().__init__()
        scaler=(2/node_dim)**0.5 # He Initialization
        self.theta1=nn.Parameter(torch.randn(node_dim)*scaler)
        self.theta2=nn.Parameter(torch.randn(node_dim)*scaler)

    def forward(self,node,degree):
        node=self.theta1*node+torch.log(degree+1).unsqueeze(dim=-1)*node*self.theta2
        return node

class LayerNorm_NoBias(nn.Module):
    def __init__(self,dim):
        super().__init__()
        self.eps=1e-05
        self.gamma=nn.Parameter(torch.ones(dim))

    def forward(self,x):
        return x/torch.sqrt(torch.var(x,dim=-1)+self.eps).unsqueeze(dim=-1)*self.gamma

class GRIT_encoder(nn.Module):
    def __init__(self,node_dim,edge_dim,num_heads,num_hops,rw_dim=4):
        super().__init__()
        self.attentions=Multi_Head_Attention(node_dim,edge_dim,num_heads,num_hops,rw_dim)
        self.degree_scaler=DegScaler(node_dim)
        self.FFN=FFN(node_dim)

        self.ln1=nn.LayerNorm(node_dim)
        self.ln2=nn.LayerNorm(node_dim)
        self.ln_edge=nn.LayerNorm(edge_dim)

    def forward(self,x):
        node,edge,degree,rw=x

        x=self.attentions(x)

        node=x[0]+node
        edge=self.ln_edge(edge+x[1])

        node=self.degree_scaler(node,degree)

        node=self.ln1(node)
        node=self.ln2(node+self.FFN(node))
        return [node,edge,degree,x[3]]
