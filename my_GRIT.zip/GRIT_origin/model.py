import torch
import torch.nn as nn

from embedding import Embedding
from attention import GRIT_encoder,FFN
from data import process_item

class GRIT_plus(nn.Module):
    def __init__(self,node_dim,edge_dim,num_heads,n_layers,num_hops=12,rw_dim=1,dropout=0,
                 dataset_name="ogbg-molhiv",num_classes=1):
        super().__init__()
        self.num_hops=num_hops

        self.embedding=Embedding(node_dim,edge_dim,num_hops,dropout,dataset_name)
        self.encoders=[]
        for i in range(n_layers):
            self.encoders.append(
                GRIT_encoder(node_dim,edge_dim,num_heads,num_hops,rw_dim)
            )
        self.encoders=nn.ModuleList(self.encoders)
        self.head=FFN(node_dim*3,out_dim=num_classes)

    def forward_single(self,x):
        x=process_item(x,self.num_hops-1)
        x=self.embedding(x)
        for encoderi in self.encoders:
            x=encoderi(x)
        representation = torch.concat([
            torch.mean(x[0], dim=0), torch.max(x[0], dim=0)[0], torch.sum(x[0], dim=0)
        ], dim=-1).unsqueeze(dim=0)
        return self.head(representation)

    def forward(self,x):
        results=[]
        for i in range(len(x)):
            results.append(self.forward_single(x[i]))
        return torch.concat(results,dim=0)



class Unbalanced_BCE_logits_loss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self,y_pred,y):
        y_pred=torch.nn.functional.sigmoid(y_pred)
        num0=torch.sum(y==0)
        num1=torch.sum(y==1)
        num0=num0/(num1+num0)*2
        num1 = num1 / (num1 + num0) * 2
        weight=torch.zeros_like(y_pred,device=y.device)
        weight[y==0]=num1
        weight[y==1]=num0
        return -torch.mean((y*torch.log(y_pred)+(1-y)*torch.log(1-y_pred))*weight)

class Nan_BCE_logits_loss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self,y_pred,y):
        y_pred=torch.nn.functional.sigmoid(y_pred)
        y_pred=y_pred[torch.isnan(y)==False]
        y=y[torch.isnan(y)==False]
        loss=(y * torch.log(y_pred) + (1 - y) * torch.log(1 - y_pred))
        return -torch.mean(loss)


if __name__=="__main__":
    torch.manual_seed(114)
    from ogb.graphproppred import PygGraphPropPredDataset
    from torch_geometric.data import DataLoader

    dataset = PygGraphPropPredDataset(name="ogbg-molhiv", root='../../dataset/')
    split_idx = dataset.get_idx_split()
    train_loader = DataLoader(dataset[split_idx["train"]], batch_size=32, shuffle=True)

    my_model=GRIT_plus(node_dim=128,edge_dim=64,num_heads=4,n_layers=8).cuda()
    import time
    start=time.time()
    for (stepi, x) in enumerate(train_loader, start=1):
        y_pred=my_model(x.cuda())
        print(y_pred)
        if stepi==100:
            print(time.time() - start)
            break