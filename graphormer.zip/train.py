import torch
import ogb
import pandas as pd
from ogb.graphproppred import PygGraphPropPredDataset
from data import GraphDataModule

from model import Graphormer
from lr import PolynomialDecayLR


def get_result_dict(y_preds,y):
    return {"y_true": torch.concat(y,dim=0),
            "y_pred": torch.concat(y_preds,dim=0)}

if __name__=="__main__":
    epochs = 12
    batch_size = 128
    peak_lr = 2e-4
    end_lr = 1e-9
    total_updates = 33000 * epochs / batch_size
    warmup_updates = total_updates // 10

    torch.manual_seed(114514)

    loader = GraphDataModule(dataset_name='ogbg-molhiv', batch_size=batch_size)
    loader.setup()
    train_loader = loader.train_dataloader()
    val_loader = loader.val_dataloader()
    test_loader = loader.test_dataloader()

    print("train loader length:",len(train_loader))
    print("val loader length:", len(val_loader))
    print("test loader length:", len(test_loader))

    my_model=Graphormer(
        n_layers=6,
        num_heads=32,
        hidden_dim=512,
        dropout_rate=0.1,
        intput_dropout_rate=0,
        weight_decay=0,
        ffn_dim=512,
        warmup_updates=warmup_updates,
        tot_updates=total_updates,
        peak_lr=peak_lr,
        end_lr=end_lr,
        edge_type="multi_hop",
        multi_hop_max_dist=5,
        attention_dropout_rate=0.1,
        flag=False,
        flag_m=3,
        flag_step_size=1e-3,
        flag_mag=1e-3,
        dataset_name="ogbg-molhiv",
    ).cuda()

    optimizer = torch.optim.AdamW(my_model.parameters(), lr=peak_lr, betas=(0.99, 0.999))
    scheduler = PolynomialDecayLR(
        optimizer=optimizer,
        warmup_updates=warmup_updates,
        tot_updates=total_updates,
        lr=peak_lr,
        end_lr=end_lr,
        power=1
    )

    loss_func=torch.nn.BCEWithLogitsLoss().cuda()#Unbalanced_BCE_logits_loss().cuda()
    evaluator=ogb.graphproppred.Evaluator('ogbg-molhiv')

    records=[]
    for epochi in range(epochs):
        my_model.train()
        loss_train=0
        y_preds_train=[]
        y_train=[]
        train_roc=0
        for (stepi, x) in enumerate(train_loader, start=1):
            x=x.to('cuda')
            y_pred = my_model(x)
            y=x.y.to(torch.float32)
            lossi=loss_func(y_pred,y)
            lossi.backward()
            optimizer.step()
            optimizer.zero_grad()
            scheduler.step()

            loss_train=loss_train+lossi.cpu().item()
            y_train.append(y.cpu().detach())
            y_preds_train.append(y_pred.cpu().detach())
            torch.cuda.empty_cache()
            if stepi%20==0:
                print("Training-> epoch:",epochi,"step:",stepi,"loss:",loss_train/stepi,
                      "rocauc:",evaluator.eval(get_result_dict(y_preds_train,y_train)))
        #get_acc(y_preds_train, y_train)
        result_dict = evaluator.eval(get_result_dict(y_preds_train,y_train))
        print("Finish training, epoch:",epochi,result_dict)
        train_roc=evaluator.eval(get_result_dict(y_preds_train,y_train))
        print("rocauc:",train_roc)

        loss_val = 0
        y_preds_val = []
        y_val = []
        val_roc=0
        my_model.eval()
        with torch.no_grad():
            for (stepi, x) in enumerate(val_loader, start=1):
                x=x.to('cuda')
                y_pred = my_model(x)
                y=x.y.to(torch.float32)
                lossi = loss_func(y_pred, y)
                loss_val = loss_val + lossi.cpu().item()

                y_val.append(y.cpu().detach())
                y_preds_val.append(y_pred.cpu().detach())
                torch.cuda.empty_cache()
                if stepi % 20 == 0:
                    print("Validating-> epoch:", epochi, "step:", stepi, "loss:", loss_val/stepi,
                          "rocauc:",evaluator.eval(get_result_dict(y_preds_val,y_val)))

        result_dict = evaluator.eval(get_result_dict(y_preds_val, y_val))
        print("Finish validating, epoch:", epochi, result_dict)
        val_roc=evaluator.eval(get_result_dict(y_preds_val,y_val))
        print("rocauc:",val_roc)

        loss_test = 0
        y_preds_test = []
        y_test = []
        with torch.no_grad():
            for (stepi, x) in enumerate(test_loader, start=1):
                x=x.to('cuda')
                y_pred = my_model(x)
                y=x.y.to(torch.float32)
                lossi = loss_func(y_pred, y)
                loss_test = loss_test + lossi.item()

                y_test.append(y.cpu().detach())
                y_preds_test.append(y_pred.cpu().detach())
                torch.cuda.empty_cache()
                if stepi % 20 == 0:
                    print("Testing-> epoch:", epochi, "step:", stepi, "loss:", loss_test/stepi,
                          "accuracy:","rocauc:",evaluator.eval(get_result_dict(y_preds_test,y_test)))

        result_dict = evaluator.eval(get_result_dict(y_preds_test, y_test))
        print("Finish testing, epoch:", epochi, result_dict)
        test_roc=evaluator.eval(get_result_dict(y_preds_test,y_test))
        print("rocauc:",test_roc)

        records.append([epochi,loss_train,loss_val,loss_test,train_roc,val_roc,test_roc])
        df = pd.DataFrame(columns=["epoch","loss_train","loss_val","loss_test","train_roc","val_roc","test_roc"],data=records)
        df.to_csv("./records.csv")